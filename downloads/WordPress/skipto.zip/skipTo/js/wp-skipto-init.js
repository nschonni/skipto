/* exported Wordpress */
var Wordpress =	{
	"settings": {
		"skipTo": {
      attachElem: 'header',
      landmarks: 'main, [role="main"], [role="search"], nav, [role="navigation"]',
      headings: 'h1, h2',
      accessKey: 'S'
		}
	}
};
